exports.getDashboard = async (req, res, next) => {
  return res.json({ msg: "welcome api" });
};
